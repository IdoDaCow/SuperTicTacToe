var gamechecker =  5; // checks if the user is allowed to put a piece in a specific board. starts at 5 because the first board used is the middle one (board #5)
var turn = 0; // 0 = x, 1 = o
var locked= 0;
var eventinterval;
var event = document.getElementById('eventbox');
var eventseconds = 5;
var count = 0;
var intervalcooldown = 0;
var xwins = 0;
var owins = 0;
DynamicTableBuild();
function DynamicTableBuild() // This function creates the game tables dynamically.
{                           // It creates the game buttons, applies them to the tds, which are applied (appended) into the tr's, 
    var table;              // which are appended into the tables, which are appended into the main game div/
    var tr;                 // this function also marks the center board with a red border because its the starting board.
    var td;
    var button;
    var count = 1;
    var br;
    var div = document.getElementById("game_tables");
    for(var i = 1; i<10; i++)
    {
        table = document.createElement('table');
        table.setAttribute("id", "gametbl"+i);
        table.setAttribute("class", "gametables");
        for(var j = 1; j<4; j++)
        {
            tr = document.createElement('tr');
            for(var k = 1; k<4; k++)
            {
                td = document.createElement('td');
                td.setAttribute("class","gametables_td");
                button = document.createElement("button");
                button.setAttribute("class", "gamebuttons");
                button.setAttribute("id", i+"_btn"+count);
                button.setAttribute("onclick", "PutPiece('"+i+"_btn"+count+"', "+i+")");
                count++;
                if(count==10)
                count=1;
                td.appendChild(button);
                tr.appendChild(td)
            }
            table.appendChild(tr);
        }
        div.appendChild(table);
        if(i%3==0)
        {
            br = document.createElement('br');
            div.appendChild(br);
        }
    }
    for(var i = 1; i<10; i++)
        document.getElementById('5_btn'+i).setAttribute("style","border: solid 2px red;");
}
function PutPiece(buttonId, board) // This function adds the symbols into the td's according to the turn, it also checks if the special
{                                   // full-board-entrance alogirthm problem happened. (more info in MismachTiud.docx)
    var square = parseInt(buttonId[5]); // The function also checks if the game is over (count==81) which means that all the boards are full.
    var button = document.getElementById(buttonId);
    var inner = button.innerHTML;
    if(board==gamechecker && inner.length==0 && intervalcooldown == 0)
    {
        if(turn==0)
            button.innerHTML = '<i class="fa fa-times" style="color: red;" aria-hidden="true"></i>';
        else
            button.innerHTML = '<i class="fa fa-circle-thin" style="color: blue;" aria-hidden="true"></i>';
        count++;
        if(count==81)
            winalert();
        for(var j = 1; j<10; j++)
            document.getElementById(gamechecker+'_btn'+j).setAttribute("style","border: solid 2px black;");
        gamechecker=square;
        for(var i = 1; i<10; i++)
            document.getElementById(gamechecker+'_btn'+i).setAttribute("style","border: solid 2px red;");
        if(turn==0)
        {
            turn=1;
            document.getElementById('turntitle').setAttribute("style", "color: blue");
            document.getElementById('turntitle').innerHTML = "Turn: O";
            wincheck(square,board, 0);
        }
        else
        {
            turn=0;
            document.getElementById('turntitle').setAttribute("style", "color: red");
            document.getElementById('turntitle').innerHTML = "Turn: X";
            wincheck(square,board, 1);
        }
        if(count!=81)
        {
            var i1 = document.getElementById(square+'_btn1').innerHTML.length;
            var i2 = document.getElementById(square+'_btn2').innerHTML.length;
            var i3 = document.getElementById(square+'_btn3').innerHTML.length;
            var i4 = document.getElementById(square+'_btn4').innerHTML.length;
            var i5 = document.getElementById(square+'_btn5').innerHTML.length;
            var i6 = document.getElementById(square+'_btn6').innerHTML.length;
            var i7 = document.getElementById(square+'_btn7').innerHTML.length;
            var i8 = document.getElementById(square+'_btn8').innerHTML.length;
            var i9 = document.getElementById(square+'_btn9').innerHTML.length;
            if(i1 != 0 && i2 != 0 && i3 != 0 && i4 != 0 && i5 != 0 && i6 != 0 && i7 != 0 && i8 != 0 && i9 != 0)
            {
                for(var j = 1; j<10; j++)
                {
                    document.getElementById(square+'_btn'+j).style.border = "solid 2px black";
                    document.getElementById(square+'_btn'+j).style.backgroundColor = "#97CAF6";
                }
                locked = 1;
                while(locked==1)
                {
                    square = Math.floor((Math.random() * 9) + 1);
                    i1 = document.getElementById(square+'_btn1').innerHTML.length;
                    i2 = document.getElementById(square+'_btn2').innerHTML.length;
                    i3 = document.getElementById(square+'_btn3').innerHTML.length;
                    i4 = document.getElementById(square+'_btn4').innerHTML.length;
                    i5 = document.getElementById(square+'_btn5').innerHTML.length;
                    i6 = document.getElementById(square+'_btn6').innerHTML.length;
                    i7 = document.getElementById(square+'_btn7').innerHTML.length;
                    i8 = document.getElementById(square+'_btn8').innerHTML.length;
                    i9 = document.getElementById(square+'_btn9').innerHTML.length;
                    if(i1 != 0 && i2 != 0 && i3 != 0 && i4 != 0 && i5 != 0 && i6 != 0 && i7 != 0 && i8 != 0 && i9 != 0)
                        console.log('The random board is full. Trying again.');
                    else
                    {
                        intervalcooldown=1;
                        document.getElementById('eventbox').setAttribute("style", "display: block;");
                        eventinterval = setInterval("eventRotation()",1000);
                        locked = 0;
                        gamechecker=square;
                        for(var i = 1; i<10; i++)
                            document.getElementById(gamechecker+'_btn'+i).setAttribute("style","border: solid 2px red;");
                        turn=1;
                        document.getElementById('turntitle').setAttribute("style", "color: blue");
                        document.getElementById('turntitle').innerHTML = "Turn: O";
                    }
                }
            }
        }
    }
}
function wincheck(square, board, currentTurn) // This function checks if there is a win in the board. If the newly-placed square is a part
{                                               // of the win, which means that it caused a new win, wincheck will call the function whoWins().
    var currentSquare = document.getElementById(board+"_btn"+square);
    var squares = new Array(10);
    for(var i=1; i<10; i++) // the first index of the array (squares[0]) is empty to make it easier to understand the code.
        squares[i] = document.getElementById(board+'_btn'+i);
    
    for(var i=1; i<8; i+=3)
    {
        if(squares[i].innerHTML == squares[i+1].innerHTML && squares[i].innerHTML == squares[i+2].innerHTML && squares[i].innerHTML.length>0)
        {
            squares[i].setAttribute("style", "background-color: yellow;");
            squares[i+1].setAttribute("style", "background-color: yellow;");
            squares[i+2].setAttribute("style", "background-color: yellow;");
            if(currentSquare == squares[i] || currentSquare == squares[i+1] || currentSquare == squares[i+2])
                whoWins(currentTurn);
        }
    }
    for(var i=1; i<4; i++)
    {
        if (squares[i].innerHTML == squares[i+3].innerHTML && squares[i].innerHTML == squares[i+6].innerHTML && squares[i].innerHTML.length>0)
        {
                squares[i].setAttribute("style", "background-color: yellow;");
                squares[i+3].setAttribute("style", "background-color: yellow;");
                squares[i+6].setAttribute("style", "background-color: yellow;");
            if(currentSquare == squares[i] || currentSquare == squares[i+3] || currentSquare == squares[i+6])
                whoWins(currentTurn);
        }
    }
    if (squares[1].innerHTML == squares[5].innerHTML && squares[1].innerHTML == squares[9].innerHTML && squares[1].innerHTML.length>0)
    {
        squares[1].setAttribute("style", "background-color: yellow;");
        squares[5].setAttribute("style", "background-color: yellow;");
        squares[9].setAttribute("style", "background-color: yellow;");
        if(currentSquare == squares[1] || currentSquare == squares[5] || currentSquare == squares[9])
                whoWins(currentTurn);
    }
    if (squares[3].innerHTML == squares[5].innerHTML && squares[3].innerHTML == squares[7].innerHTML && squares[3].innerHTML.length>0)
    {
        squares[3].setAttribute("style", "background-color: yellow;");
        squares[5].setAttribute("style", "background-color: yellow;");
        squares[7].setAttribute("style", "background-color: yellow;");
        if(currentSquare == squares[3] || currentSquare == squares[5] || currentSquare == squares[7])
                whoWins(currentTurn);
    }
}
function whoWins(currentTurn) // This function is called when there's a new win (called by wincheck()), the point is to add a win to the correct player
{                               // according to the global variable "turn". 
    if(currentTurn==0)
    {
        xwins++;
        document.getElementById('xwinscount').innerHTML = xwins;
    }
    else
    {
        owins++;
        document.getElementById('owinscount').innerHTML = owins;
    }
}
function winalert() // This function is called when the game is complete (count==81, which means that all the cells of the boards are full)
{                   // The point is to announce who won the game (or if it was a tie), according to the owins and xwins global variables.
    if(xwins<owins)
    {
        document.getElementById('winner').setAttribute("style","color: blue;")
        document.getElementById('winner').innerHTML="Blue (O)";
        document.getElementById('gameresult_box').setAttribute("style", "display: block;");
    }
    else if(xwins>owins)
    {
        document.getElementById('winner').setAttribute("style","color: red;")
        document.getElementById('winner').innerHTML="Red (X)";
        document.getElementById('gameresult_box').setAttribute("style", "display: block;");
    }
    else
    {
        document.getElementById('winner').setAttribute("style","color: orange;")
        document.getElementById('winner').innerHTML="THERE WAS A TIE!";
        document.getElementById('gameresult_box').setAttribute("style", "display: block;");
    }
}
function eventRotation() // This function is called when the special full-board-entrance alogirthm problem happens, the point is to explain 
{                       // what happened and provide info about why the player was sent to a random board. (More info about the full-board-entrance
    eventseconds--;     // algorithm problem in MismachTiud.docx).
    if(eventseconds>0)
        document.getElementById('event_secondcounter').innerHTML = eventseconds;
    if(eventseconds==0)
        {
            document.getElementById('eventbox').setAttribute("style", "display: none;");
            document.getElementById('event_secondcounter').innerHTML = 5;
            clearInterval(eventinterval);
            eventseconds = 5;
            intervalcooldown=0;
        }
}
function newGame() // The point of this function is to restart the game, without refreshing the page and reopening the files which takes a lot of time
{                // (it doesnt actually take a lot of time, but this function makes the process faster so users will be able to start a new game quickly)
    for(var i=1; i<10; i++)
    {
        for(var j=1; j<10; j++)
        {
            document.getElementById(i+'_btn'+j).innerHTML = '';
            document.getElementById(i+'_btn'+j).setAttribute('style', 'background-color: none;');
        }
    }
    xwins = 0;
    owins = 0;
    turn = 0;
    count = 0;
    document.getElementById('xwinscount').innerHTML = '0';
    document.getElementById('owinscount').innerHTML = '0';
    document.getElementById('turntitle').setAttribute("style", "color: red");
    document.getElementById('turntitle').innerHTML = "Turn: X";
    gamechecker = 5;
    for(var i = 1; i<10; i++)
    document.getElementById(gamechecker+'_btn'+i).setAttribute("style","border: solid 2px red;");
    document.getElementById('gameresult_box').setAttribute("style","display: none;");
}
function switchPlayer() // The point of this function is to switch the turns between x and o if the user wants to change it. 
{                       // the function changes the turn's value from 0 to 1 or 1 to 0, and also changes the turn title in the dashboard accordingly.
    if(turn==1)
    {
        turn=0;
        document.getElementById('turntitle').setAttribute("style", "color: red");
        document.getElementById('turntitle').innerHTML = "Turn: X";
    }
    else
    {
        turn=1;
        document.getElementById('turntitle').setAttribute("style", "color: blue");
        document.getElementById('turntitle').innerHTML = "Turn: O";
    }
}